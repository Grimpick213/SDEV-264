package com.example.finalproject


import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        helpActivityBtn.setOnClickListener {
            val intent = Intent(
                this,
                HelpActivity::class.java
            )
            startActivity(intent)
        }
        submitButton.setOnClickListener {
            val intent3 = Intent(
                this, SecondaryActivity::class.java
            )
            startActivity(intent3)
        }
        settingsBtn.setOnClickListener{
            val intent4 = Intent(
                this, PreferenceActivity::class.java
            )
            startActivity(intent4)
    }

    }
}




